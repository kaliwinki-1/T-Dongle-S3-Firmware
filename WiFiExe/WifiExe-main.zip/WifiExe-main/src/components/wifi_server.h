#ifndef WIFI_SERVER_H
#define WIFI_SERVER_H

#include <WebServer.h>

extern WebServer server;

void setup_WiFi();

#endif
