#ifndef WEB_CONTENT_H
#define WEB_CONTENT_H

extern const char *cssStyles;
extern const char *rootViewHTML;
extern const char *folderViewHTML;
extern const char *fileViewHTML;
extern const char *redirectToRoot;

#endif
